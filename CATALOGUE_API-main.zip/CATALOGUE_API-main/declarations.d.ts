declare module 'koa-router';
declare module '@koa/cors';
declare module 'koa-bodyparser';
declare module 'yamljs';
declare module 'luxon';
declare module 'amqplib';
declare module 'jest';
declare module 'yamljs';
